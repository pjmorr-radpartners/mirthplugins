
This plugin includes a portion of images from http://www.famfamfam.com/lab/icons/silk/
